# Quiz-bank
[![Coverage Status](https://coveralls.io/repos/github/awesome-5/Quiz-bank/badge.svg)](https://coveralls.io/github/awesome-5/Quiz-bank)

[![Build Status](https://travis-ci.com/awesome-5/Quiz-bank.svg?branch=master)](https://travis-ci.com/awesome-5/Quiz-bank)
